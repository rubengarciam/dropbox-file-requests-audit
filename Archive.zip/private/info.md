## File Request Audit Tool


- beta v0.2
- March 22, 2016
- created by ruben@dropbox.com

This is an unofficial app to showcase how to obtain file requests submitters email from the Dropbox Business API. It comes with no support from Dropbox.

For further info, comments, etc please access [this Dropbox Paper document](https://paper.dropbox.com/doc/File-Requests-Audit-Log-App-ZQlfMNXtKQ1u4GBLLeVsx).
