/*Meteor.publish(function(){
  return Markdown.find();
  return Logs.find();
});*/
